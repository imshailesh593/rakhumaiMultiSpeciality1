
<footer class="ftco-footer ftco-bg-dark ftco-section">
<div class="container">
<div class="row mb-5">
<div class="col-md">
<div class="ftco-footer-widget mb-5">
<h2 class="ftco-heading-2 logo">Rakhumai<span>Multispeciality</span></h2>
<p>Rakhumai Multispeciality ICU Hospital is dedicated to providing exceptional critical care with state-of-the-art medical technology. Our team of highly skilled specialists offers round-the-clock monitoring and expert treatment in a compassionate and supportive environment. Committed to the health and well-being of our patients, we ensure top-tier medical care in our advanced facility.</p>
</div>
<div class="ftco-footer-widget mb-5">
<h2 class="ftco-heading-2">Have a Questions?</h2>
<div class="block-23 mb-3">
<ul>
<li><span class="icon icon-map-marker"></span><span class="text"><a href="https://maps.app.goo.gl/LKZSRHrCtf6eFsro6">At post Bhose Pati, Bhose</span></li>
<li><a href="Tel:919765937210"><span class="icon icon-phone"></span><span class="text">+919765937210</span></a></li>
<li><a href="https://wa.me/919765937210"><span class="icon icon-phone"></span><span class="text">Whatsapp us!</span></a></li>
</ul>
</div>
<ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
<li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
<li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
<li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
</ul>
</div>
</div>
<div class="col-md">
<div class="ftco-footer-widget mb-5 ml-md-4">
<h2 class="ftco-heading-2">Links</h2>
<ul class="list-unstyled">
<li><a href="#"><span class="ion-ios-arrow-round-forward mr-2"></span>Home</a></li>
<li><a href="#"><span class="ion-ios-arrow-round-forward mr-2"></span>About</a></li>
<li><a href="#"><span class="ion-ios-arrow-round-forward mr-2"></span>Services</a></li>
<li><a href="#"><span class="ion-ios-arrow-round-forward mr-2"></span>Deparments</a></li>
<li><a href="#"><span class="ion-ios-arrow-round-forward mr-2"></span>Contact</a></li>
</ul>
</div>

<div class="ftco-footer-widget mb-5 ml-md-4">
<h2 class="ftco-heading-2">Services</h2>
<ul class="list-unstyled">
<li><a href="#"><span class="ion-ios-arrow-round-forward mr-2"></span>Neurolgy</a></li>
<li><a href="#"><span class="ion-ios-arrow-round-forward mr-2"></span>Dentist</a></li>
<li><a href="#"><span class="ion-ios-arrow-round-forward mr-2"></span>Ophthalmology</a></li>
<li><a href="#"><span class="ion-ios-arrow-round-forward mr-2"></span>Cardiology</a></li>
<li><a href="#"><span class="ion-ios-arrow-round-forward mr-2"></span>Surgery</a></li>
</ul>
</div>
</div>
<div class="col-md">
<div class="ftco-footer-widget mb-5">
<h2 class="ftco-heading-2">Recent Posts</h2>
<div class="block-21 mb-4 d-flex">
<a class="blog-img mr-4" style="background-image: url(images/image_1.jpg);"></a>
<div class="text">
<h3 class="heading"><a href="#">Instagram posts</a></h3>
<div class="meta">
<div><a href="#"><span class="icon-calendar"></span> Dec 25, 2018</a></div>
<div><a href="#"><span class="icon-person"></span> Admin</a></div>
<div><a href="#"><span class="icon-chat"></span> 19</a></div>
</div>
</div>
</div>
<div class="block-21 mb-5 d-flex">
<a class="blog-img mr-4" style="background-image: url(images/image_2.jpg);"></a>
<div class="text">
<h3 class="heading"><a href="#">Instagram posts</a></h3>
<div class="meta">
<div><a href="#"><span class="icon-calendar"></span> Dec 25, 2018</a></div>
<div><a href="#"><span class="icon-person"></span> Admin</a></div>
<div><a href="#"><span class="icon-chat"></span> 19</a></div>
</div>
</div>
</div>
</div>
</div>
<div class="col-md">
<div class="ftco-footer-widget mb-5">
<h2 class="ftco-heading-2">Opening Hours</h2>
<h3 class="open-hours pl-4"><span class="ion-ios-time mr-3"></span>We are open 24/7</h3>
</div>


</div>
</div>
<div class="row">
<div class="col-md-12 text-center">
<p>
Copyright &copy;<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> All rights reserved | Designed, Developed & Maintained by <i class="icon-heart" aria-hidden="true"></i> by <a href="https://mavericinfotech.in/" target="_blank">Maveric InfoTech</a>
</p>
</div>
</div>
</div>
</footer>

<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" /><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00" /></svg></div>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/jquery.timepicker.min.js"></script>
<script src="js/scrollax.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&amp;sensor=false"></script>
<script src="js/google-map.js"></script>
<script src="js/main.js"></script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"rayId":"8975de42bff785fa","b":1,"version":"2024.4.1","token":"cd0b4b3a733644fc843ef0b185f98241"}' crossorigin="anonymous"></script>
